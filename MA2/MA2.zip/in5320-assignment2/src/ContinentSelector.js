import React from "react";

const CONTINENTS = [
  "Africa",
  "Asia",
  "Europe",
  "North America",
  "South America",
  "Oceania",
  "Antarctica",
];

function ContinentSelector({ selected = [], onChange }) {
  const toggle = (name) => {
    const set = new Set(selected);
    if (set.has(name)) set.delete(name); else set.add(name);
    onChange?.(Array.from(set));
  };

  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 12, margin: "8px 0 12px" }}>
      {CONTINENTS.map((c) => (
        <label key={c} style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <input
            type="checkbox"
            checked={selected.includes(c)}
            onChange={() => toggle(c)}
          />
          {c}
        </label>
      ))}
    </div>
  );
}

export default ContinentSelector;

