import React from "react";

function PageSizeSelector({ pageSize, onChange }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
      <label htmlFor="page-size">Results per page:</label>
      <select
        id="page-size"
        value={pageSize}
        onChange={(e) => onChange?.(parseInt(e.target.value, 10))}
        style={{ padding: 6 }}
      >
        <option value={10}>10</option>
        <option value={20}>20</option>
        <option value={50}>50</option>
      </select>
    </div>
  );
}

export default PageSizeSelector;

