import React, { useState, useEffect } from "react";
import "./App.css";
import Table from "./Table.js";
import SearchBar from "./SearchBar";
import PageSizeSelector from "./PageSizeSelector";
import Pagination from "./Pagination";
import ContinentSelector from "./ContinentSelector";

function App() {

  const [apiData, setApiData] = useState([]);
  const [searchQuery, setSearchQuery] = useState(); 
  const [searchText, setSearchText] = useState(""); 
  const [pageNumber, setPageNumber] = useState(1); 
  const [pageSize, setPageSize] = useState(10); 
  const [continents, setContinents] = useState([]); 

  useEffect(() => {
    
    let apiQuery = "https://dhis2-app-course.ifi.uio.no/api?"
    
    if (searchQuery) {
      apiQuery = apiQuery + "&search=" + encodeURIComponent(searchQuery);
    }

    
    apiQuery = apiQuery + "&page=" + pageNumber;
    
    if (pageSize) {
      apiQuery = apiQuery + "&pageSize=" + pageSize;
    }
    
    if (continents && continents.length > 0) {
      apiQuery += continents.map((c) => `&continent=${encodeURIComponent(c)}`).join("");
    }

    
    console.log("Querying: " + apiQuery);
    fetch(apiQuery)
      .then((results) => results.json())
      .then((data) => {
        
        setApiData(data);
      })
      .catch((err) => console.error("API error", err));
  }, [searchQuery, pageNumber, pageSize, continents]); 

  
  const currentPage = apiData?.page ?? apiData?.pageNumber ?? pageNumber;
  const totalPages = apiData?.totalPages ?? apiData?.total_pages ?? apiData?.pages ?? apiData?.pageCount;
  const resultsLen = apiData?.results?.length ?? 0;
  const canGoPrev = currentPage > 1;
  const canGoNext =
    totalPages != null ? currentPage < totalPages : resultsLen > 0 && resultsLen >= pageSize;

  const triggerSearch = () => {
    setSearchQuery(searchText || undefined);
    setPageNumber(1);
  };

  const changePageSize = (size) => {
    setPageSize(size);
    setPageNumber(1);
  };

  const prevPage = () => setPageNumber((p) => Math.max(1, p - 1));
  const nextPage = () => setPageNumber((p) => p + 1);

  return (
    <div className="App">
      <h1>Country lookup</h1>

      <SearchBar value={searchText} onChange={setSearchText} onSearch={triggerSearch} />

      <PageSizeSelector pageSize={pageSize} onChange={changePageSize} />

      {/* Optional: Continent selector */}
      <ContinentSelector selected={continents} onChange={(vals) => { setContinents(vals); setPageNumber(1); }} />

      <Table apiData={apiData} />

      <Pagination
        pageNumber={currentPage}
        totalPages={totalPages}
        canGoPrev={canGoPrev}
        canGoNext={canGoNext}
        onPrev={prevPage}
        onNext={nextPage}
      />
    </div>
  );
}

export default App;
