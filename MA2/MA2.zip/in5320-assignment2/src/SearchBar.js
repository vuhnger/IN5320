import React from "react";

function SearchBar({ value, onChange, onSearch }) {
  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch?.();
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 12 }}>
      <input
        type="text"
        placeholder="Search countries..."
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        style={{ flex: 1, padding: 8 }}
      />
      <button type="submit" disabled={!value} style={{ padding: "8px 12px" }}>
        Search
      </button>
    </form>
  );
}

export default SearchBar;

