import React from "react";

function Pagination({
  pageNumber,
  totalPages,
  canGoPrev,
  canGoNext,
  onPrev,
  onNext,
}) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 12 }}>
      {canGoPrev ? (
        <button onClick={onPrev}>&lt; Prev</button>
      ) : null}
      <span>
        Page {pageNumber}
        {totalPages ? ` of ${totalPages}` : ""}
      </span>
      {canGoNext ? (
        <button onClick={onNext}>Next &gt;</button>
      ) : null}
    </div>
  );
}

export default Pagination;

