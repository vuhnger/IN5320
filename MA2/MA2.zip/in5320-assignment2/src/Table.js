import React, { useMemo, useState } from "react";


const getCountry = (item) => item?.country ?? item?.name ?? item?.Country ?? "";
const getContinent = (item) =>
  item?.continent ?? item?.region ?? item?.Continent ?? "";
const getPopulation = (item) =>
  item?.population ?? item?.Population ?? item?.pop ?? null;
const getPopulationGrowth = (item) =>
  item?.population_growth ?? item?.populationGrowth ?? item?.PopulationGrowth ??
  item?.["Population Growth"] ?? null;

function Table({ apiData }) {
  const [sortBy, setSortBy] = useState(null); 
  const [sortDir, setSortDir] = useState("asc"); 

  const results = apiData?.results ?? [];

  const sorted = useMemo(() => {
    if (!sortBy) return results;
    const getterMap = {
      country: getCountry,
      continent: getContinent,
      population: getPopulation,
      populationGrowth: getPopulationGrowth,
    };
    const getter = getterMap[sortBy];
    const copy = [...results];
    copy.sort((a, b) => {
      const va = getter(a);
      const vb = getter(b);
      
      const na = typeof va === "number" || (va !== null && !isNaN(Number(va)));
      const nb = typeof vb === "number" || (vb !== null && !isNaN(Number(vb)));
      if (na && nb) {
        const diff = Number(va) - Number(vb);
        return sortDir === "asc" ? diff : -diff;
      }
      
      const sa = (va ?? "").toString();
      const sb = (vb ?? "").toString();
      const cmp = sa.localeCompare(sb);
      return sortDir === "asc" ? cmp : -cmp;
    });
    return copy;
  }, [results, sortBy, sortDir]);

  const toggleSort = (key) => {
    if (sortBy === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(key);
      setSortDir("asc");
    }
  };

  if (!apiData || !apiData.results) {
    return <p>Loading...</p>;
  }

  return (
    <table style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr>
          <th
            onClick={() => toggleSort("country")}
            style={{ cursor: "pointer", textAlign: "left", borderBottom: "1px solid #ccc", padding: "8px" }}
          >
            Country{sortBy === "country" ? (sortDir === "asc" ? " ▲" : " ▼") : ""}
          </th>
          <th
            onClick={() => toggleSort("continent")}
            style={{ cursor: "pointer", textAlign: "left", borderBottom: "1px solid #ccc", padding: "8px" }}
          >
            Continent{sortBy === "continent" ? (sortDir === "asc" ? " ▲" : " ▼") : ""}
          </th>
          <th
            onClick={() => toggleSort("population")}
            style={{ cursor: "pointer", textAlign: "right", borderBottom: "1px solid #ccc", padding: "8px" }}
          >
            Population{sortBy === "population" ? (sortDir === "asc" ? " ▲" : " ▼") : ""}
          </th>
          <th
            onClick={() => toggleSort("populationGrowth")}
            style={{ cursor: "pointer", textAlign: "right", borderBottom: "1px solid #ccc", padding: "8px" }}
          >
            Population Growth{sortBy === "populationGrowth" ? (sortDir === "asc" ? " ▲" : " ▼") : ""}
          </th>
        </tr>
      </thead>
      <tbody>
        {sorted.map((row, idx) => (
          <tr key={idx}>
            <td style={{ borderBottom: "1px solid #eee", padding: "8px" }}>{getCountry(row)}</td>
            <td style={{ borderBottom: "1px solid #eee", padding: "8px" }}>{getContinent(row)}</td>
            <td style={{ borderBottom: "1px solid #eee", padding: "8px", textAlign: "right" }}>{
              getPopulation(row)?.toLocaleString?.() ?? getPopulation(row)
            }</td>
            <td style={{ borderBottom: "1px solid #eee", padding: "8px", textAlign: "right" }}>{
              getPopulationGrowth(row) !== null && getPopulationGrowth(row) !== undefined
                ? `${Number(getPopulationGrowth(row))}`
                : ""
            }</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default Table;
